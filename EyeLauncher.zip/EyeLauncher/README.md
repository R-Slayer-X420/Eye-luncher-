# Eye Launcher (Android TV)

A TV home screen with a row of apps along the bottom and a character whose eyes follow
whichever app icon you have selected. Apps can be rearranged, characters and eye styles are
swappable, and the background is animated (rain by default, or a looping video).

## Build and install

1. Open this folder in **Android Studio** (it will download Gradle and the Android SDK pieces).
2. Build > Build APK(s). The file ends up in `app/build/outputs/apk/debug/app-debug.apk`.
3. Install on the TV. With developer options and network debugging turned on:
   ```
   adb connect <tv-ip-address>
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```
4. Open **Eye Launcher** from your TV's app list.

Some Android TV / Google TV models won't let you pick a third-party home screen as the
default. If yours doesn't, the launcher still works when you open it from the apps list.

## Using it

- **D-pad** moves between apps; the eyes track the selected one. **OK** opens the app.
- **Hold OK** on an app to pick it up, **Left/Right** to move it, **OK** to drop it.
  The order is remembered.
- **Menu button** (or the last tile, "Customize") opens settings: character, eye style,
  background, reset order.

## Adding your own characters and eyes

You supply the artwork. Copy files to the app's folder on the TV (the exact path is shown in
Customize > "How to add characters..."). Typically:

```
adb push my_character /sdcard/Android/data/com.example.eyelauncher/files/characters/
adb push my_eye.png   /sdcard/Android/data/com.example.eyelauncher/files/eyes/
```

A character is a folder containing a `pack.json` and an image:

```
characters/my_character/
  pack.json
  character.png      <- your artwork; use a transparent PNG if you want the rain/video behind it
  background.mp4     <- optional looping video (Customize > Background > Auto)
  eyes/              <- optional eye images that only appear for this character
```

`pack.json`:

```json
{
  "name": "My Character",
  "image": "character.png",
  "socketColor": "#0B0F1A",
  "background": "background.mp4",
  "eyes": [
    { "x": 0.43, "y": 0.41, "r": 0.030 },
    { "x": 0.57, "y": 0.41, "r": 0.030 }
  ]
}
```

- `x`, `y`: eye center as a fraction of the image (pixel position divided by image width/height).
- `r`: eye radius as a fraction of the image **width**.
- `socketColor`: color painted behind the moving iris. Match it to the character's eye area.
- `background` is optional.

**Eye styles** are just square PNGs (transparent background works best). Put them in `eyes/`
(shared by all characters) or in a character's own `eyes/` folder. If a file name starts with
`spin`, the image slowly rotates.

Tip: paint the eye area of your character artwork plain (no iris), so the moving iris is the
only one visible.
