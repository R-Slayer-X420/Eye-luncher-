package com.example.eyelauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

/** An animated rainy-night background that costs almost nothing to run. */
class RainView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class Drop(var x: Float, var y: Float, val len: Float, val speed: Float, val alpha: Int)

    private val drops = ArrayList<Drop>()
    private val rnd = Random(7)
    private val bg = Paint()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 2.5f
    }
    private var last = 0L

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        bg.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#0E2036"), Color.parseColor("#03060B"),
            Shader.TileMode.CLAMP
        )
        drops.clear()
        val n = ((w * h) / 9000).coerceIn(80, 400)
        repeat(n) { drops.add(newDrop(w, h)) }
    }

    private fun newDrop(w: Int, h: Int) = Drop(
        x = rnd.nextFloat() * w * 1.2f,
        y = rnd.nextFloat() * h,
        len = 30f + rnd.nextFloat() * 70f,
        speed = 900f + rnd.nextFloat() * 900f,
        alpha = 40 + rnd.nextInt(90)
    )

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        last = 0L
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        for (d in drops) {
            d.y += d.speed * dt
            d.x -= d.speed * dt * 0.12f
            if (d.y - d.len > height || d.x < -50f) {
                d.x = rnd.nextFloat() * width * 1.2f
                d.y = -d.len
            }
            line.color = Color.argb(d.alpha, 170, 200, 255)
            canvas.drawLine(d.x, d.y, d.x + d.len * 0.12f, d.y - d.len, line)
        }
        postInvalidateOnAnimation()
    }
}
