package com.example.eyelauncher

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** The row of app icons. The last tile is always the "Customize" button. */
class AppAdapter(
    private val settingsIcon: Drawable?,
    private val onLaunch: (AppEntry) -> Unit,
    private val onSettings: () -> Unit,
    private val onFocused: (View) -> Unit,
    private val onStartMove: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    val apps = ArrayList<AppEntry>()
    var movingPkg: String? = null
        private set

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount() = apps.size + 1

    override fun onBindViewHolder(h: VH, position: Int) {
        val v = h.itemView
        if (position == apps.size) {
            h.icon.setImageDrawable(settingsIcon)
            h.label.text = v.context.getString(R.string.customize)
            v.setOnClickListener { onSettings() }
            v.setOnLongClickListener(null)
        } else {
            val app = apps[position]
            h.icon.setImageDrawable(app.icon)
            h.label.text = if (app.pkg == movingPkg) "◀  move  ▶" else app.label
            v.setOnClickListener { onLaunch(app) }
            v.setOnLongClickListener {
                onStartMove(app)
                true
            }
        }
        val scale = if (v.hasFocus()) 1.25f else 1f
        v.scaleX = scale
        v.scaleY = scale
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) 1.25f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(120).start()
            if (hasFocus) onFocused(view)
        }
    }

    fun submit(list: List<AppEntry>) {
        apps.clear()
        apps.addAll(list)
        movingPkg = null
        notifyDataSetChanged()
    }

    fun startMove(pkg: String) {
        movingPkg = pkg
        val i = apps.indexOfFirst { it.pkg == pkg }
        if (i >= 0) notifyItemChanged(i)
    }

    fun endMove() {
        val pkg = movingPkg ?: return
        movingPkg = null
        val i = apps.indexOfFirst { it.pkg == pkg }
        if (i >= 0) notifyItemChanged(i)
    }

    /** Moves the app being rearranged by [delta] slots. Returns its new position, or -1. */
    fun moveMoving(delta: Int): Int {
        val pkg = movingPkg ?: return -1
        val from = apps.indexOfFirst { it.pkg == pkg }
        if (from < 0) return -1
        val to = (from + delta).coerceIn(0, apps.size - 1)
        if (to != from) {
            val item = apps.removeAt(from)
            apps.add(to, item)
            notifyItemMoved(from, to)
        }
        return to
    }
}
