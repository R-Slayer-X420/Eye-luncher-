package com.example.eyelauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import org.json.JSONObject
import java.io.File

/** One eye. x/y are fractions of the image width/height, r is a fraction of the image width. */
data class EyeSpec(val x: Float, val y: Float, val r: Float)

data class CharacterPack(
    val id: String,
    val name: String,
    val imageFile: File?,
    val eyes: List<EyeSpec>,
    val socketColor: Int,
    val backgroundFile: File?,
    val dir: File?
)

data class EyeStyle(
    val id: String,
    val label: String,
    val file: File? = null,
    val color: Int = Color.RED,
    val spin: Boolean = false
)

/**
 * Finds character packs and eye styles that the user has copied onto the device.
 *
 * Folder layout (inside the app's files folder):
 *   characters/<pack name>/pack.json
 *   characters/<pack name>/character.png   (your own artwork)
 *   characters/<pack name>/background.mp4  (optional)
 *   characters/<pack name>/eyes/*.png      (optional eye styles just for this pack)
 *   eyes/*.png                             (eye styles available to every pack)
 */
class CharacterStore(ctx: Context) {
    private val root: File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    val charactersDir = File(root, "characters")
    val eyesDir = File(root, "eyes")

    private val defaultPack = CharacterPack(
        id = "__default",
        name = "Placeholder bot",
        imageFile = null,
        eyes = listOf(EyeSpec(0.42f, 0.40f, 0.035f), EyeSpec(0.58f, 0.40f, 0.035f)),
        socketColor = Color.parseColor("#0B0F1A"),
        backgroundFile = null,
        dir = null
    )

    private val builtinStyles = listOf(
        EyeStyle("builtin:red", "Plain red", color = Color.parseColor("#E01B24")),
        EyeStyle("builtin:gold", "Plain gold", color = Color.parseColor("#F5C211")),
        EyeStyle("builtin:blue", "Plain blue", color = Color.parseColor("#3584E4")),
        EyeStyle("builtin:green", "Plain green", color = Color.parseColor("#33D17A"))
    )

    init {
        charactersDir.mkdirs()
        eyesDir.mkdirs()
    }

    fun listPacks(): List<CharacterPack> {
        val out = ArrayList<CharacterPack>()
        out.add(defaultPack)
        charactersDir.listFiles()
            ?.filter { it.isDirectory }
            ?.sortedBy { it.name.lowercase() }
            ?.forEach { dir -> readPack(dir)?.let { out.add(it) } }
        return out
    }

    fun findPack(id: String?): CharacterPack =
        listPacks().firstOrNull { it.id == id } ?: defaultPack

    fun listEyeStyles(pack: CharacterPack): List<EyeStyle> {
        val out = ArrayList<EyeStyle>(builtinStyles)
        val exts = setOf("png", "webp", "jpg", "jpeg")
        val dirs = listOfNotNull(eyesDir, pack.dir?.let { File(it, "eyes") })
        for (d in dirs) {
            d.listFiles()
                ?.filter { it.isFile && it.extension.lowercase() in exts }
                ?.sortedBy { it.name.lowercase() }
                ?.forEach { f ->
                    out.add(
                        EyeStyle(
                            id = "file:" + f.absolutePath,
                            label = f.nameWithoutExtension,
                            file = f,
                            // Name a file "spin_something.png" and the eye image slowly rotates.
                            spin = f.name.startsWith("spin", ignoreCase = true)
                        )
                    )
                }
        }
        return out
    }

    fun loadBitmap(pack: CharacterPack): Bitmap =
        pack.imageFile?.let { decodeScaled(it, 2560) } ?: defaultBitmap()

    private fun readPack(dir: File): CharacterPack? {
        val json = File(dir, "pack.json")
        if (!json.exists()) return null
        return try {
            val o = JSONObject(json.readText())
            val img = File(dir, o.optString("image", "character.png"))
            if (!img.exists()) return null
            val eyes = ArrayList<EyeSpec>()
            val arr = o.optJSONArray("eyes")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    eyes.add(
                        EyeSpec(
                            e.getDouble("x").toFloat(),
                            e.getDouble("y").toFloat(),
                            e.getDouble("r").toFloat()
                        )
                    )
                }
            }
            val bgName = o.optString("background", "")
            val bg = if (bgName.isNotEmpty()) File(dir, bgName).takeIf { it.exists() } else null
            CharacterPack(
                id = dir.name,
                name = o.optString("name", dir.name),
                imageFile = img,
                eyes = eyes,
                socketColor = Color.parseColor(o.optString("socketColor", "#0B0F1A")),
                backgroundFile = bg,
                dir = dir
            )
        } catch (e: Exception) {
            null
        }
    }

    /** A simple original placeholder (transparent background, so the rain shows through). */
    private fun defaultBitmap(): Bitmap {
        val w = 1600
        val h = 900
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.parseColor("#182742")
        c.drawRoundRect(RectF(w * 0.30f, h * 0.08f, w * 0.70f, h * 0.85f), 160f, 160f, p)
        return b
    }

    companion object {
        fun decodeScaled(file: File, maxDim: Int): Bitmap? {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDim || bounds.outHeight / sample > maxDim) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            return BitmapFactory.decodeFile(file.absolutePath, opts)
        }
    }
}
