package com.example.eyelauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Draws the character image full-screen and, on top of it, the eyes.
 * Each eye is a round "socket" with an iris image that slides toward [lookAt].
 */
class CharacterView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** The app icon the eyes should look at. */
    var lookAt: View? = null

    private var bitmap: Bitmap? = null
    private var eyes: List<EyeSpec> = emptyList()
    private var socketColor = Color.BLACK
    private var style: EyeStyle? = null
    private var styleBitmap: Bitmap? = null

    private var curX = FloatArray(0)
    private var curY = FloatArray(0)
    private var angle = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private val irisRect = RectF()
    private val clip = Path()
    private val myLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    fun setPack(bmp: Bitmap, eyes: List<EyeSpec>, socketColor: Int) {
        this.bitmap = bmp
        this.eyes = eyes
        this.socketColor = socketColor
        curX = FloatArray(eyes.size)
        curY = FloatArray(eyes.size)
        invalidate()
    }

    fun setEyeStyle(s: EyeStyle) {
        style = s
        styleBitmap = s.file?.let { CharacterStore.decodeScaled(it, 512) }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap
        if (bmp != null && width > 0 && height > 0) {
            val vw = width.toFloat()
            val vh = height.toFloat()
            val bw = bmp.width.toFloat()
            val bh = bmp.height.toFloat()
            val s = max(vw / bw, vh / bh) // center-crop
            val dx = (vw - bw * s) / 2f
            val dy = (vh - bh * s) / 2f
            dst.set(dx, dy, dx + bw * s, dy + bh * s)
            canvas.drawBitmap(bmp, null, dst, paint)

            // Where is the focused icon, in this view's coordinates?
            getLocationOnScreen(myLoc)
            var tx = vw * 0.5f
            var ty = vh
            val target = lookAt
            if (target != null && target.isAttachedToWindow) {
                target.getLocationOnScreen(targetLoc)
                tx = targetLoc[0] - myLoc[0] + target.width / 2f
                ty = targetLoc[1] - myLoc[1] + target.height / 2f
            }

            for (i in eyes.indices) {
                val eye = eyes[i]
                val cx = dx + eye.x * bw * s
                val cy = dy + eye.y * bh * s
                val r = eye.r * bw * s

                val vx = tx - cx
                val vy = ty - cy
                val dist = max(hypot(vx, vy), 1f)
                val strength = min(1f, dist / (vw * 0.35f))
                val wantX = vx / dist * strength * r * 0.45f
                val wantY = vy / dist * strength * r * 0.45f
                curX[i] += (wantX - curX[i]) * 0.18f
                curY[i] += (wantY - curY[i]) * 0.18f

                canvas.save()
                clip.reset()
                clip.addCircle(cx, cy, r, Path.Direction.CW)
                canvas.clipPath(clip)
                paint.style = Paint.Style.FILL
                paint.color = socketColor
                canvas.drawCircle(cx, cy, r, paint)
                drawIris(canvas, cx + curX[i], cy + curY[i], r * 0.62f)
                canvas.restore()
            }
            angle = (angle + 1.5f) % 360f
        }
        postInvalidateOnAnimation()
    }

    private fun drawIris(c: Canvas, x: Float, y: Float, rad: Float) {
        val st = style ?: return
        val img = styleBitmap
        if (img != null) {
            c.save()
            if (st.spin) c.rotate(angle, x, y)
            irisRect.set(x - rad, y - rad, x + rad, y + rad)
            c.drawBitmap(img, null, irisRect, paint)
            c.restore()
        } else {
            paint.style = Paint.Style.FILL
            paint.color = st.color
            c.drawCircle(x, y, rad, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = rad * 0.12f
            paint.color = darker(st.color)
            c.drawCircle(x, y, rad * 0.94f, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.BLACK
            c.drawCircle(x, y, rad * 0.3f, paint)
        }
    }

    private fun darker(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.6f).toInt(),
        (Color.green(c) * 0.6f).toInt(),
        (Color.blue(c) * 0.6f).toInt()
    )
}
