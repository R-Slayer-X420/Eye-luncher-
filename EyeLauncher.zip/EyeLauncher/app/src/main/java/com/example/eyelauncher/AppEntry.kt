package com.example.eyelauncher

import android.content.Intent
import android.graphics.drawable.Drawable

data class AppEntry(
    val pkg: String,
    val label: String,
    val icon: Drawable,
    val intent: Intent
)
