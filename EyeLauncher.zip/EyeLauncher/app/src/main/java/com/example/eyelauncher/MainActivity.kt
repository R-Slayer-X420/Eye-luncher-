package com.example.eyelauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Bundle
import android.view.KeyEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var store: CharacterStore
    private lateinit var characterView: CharacterView
    private lateinit var rainView: RainView
    private lateinit var videoView: TextureView
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: AppAdapter

    private var currentPack: CharacterPack? = null
    private var currentStyle: EyeStyle? = null

    private var player: MediaPlayer? = null
    private var surface: Surface? = null
    private var packageReceiver: BroadcastReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("eye_launcher", Context.MODE_PRIVATE)
        store = CharacterStore(this)

        characterView = findViewById(R.id.character)
        rainView = findViewById(R.id.rain)
        videoView = findViewById(R.id.video)
        recycler = findViewById(R.id.apps)

        adapter = AppAdapter(
            settingsIcon = ContextCompat.getDrawable(this, R.drawable.ic_customize),
            onLaunch = { launchApp(it) },
            onSettings = { showSettings() },
            onFocused = { characterView.lookAt = it },
            onStartMove = { adapter.startMove(it.pkg) }
        )
        recycler.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        recycler.adapter = adapter
        (recycler.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        hideSystemBars()
        applyCharacter()
    }

    override fun onStart() {
        super.onStart()
        loadApps()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                loadApps()
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        packageReceiver = receiver
    }

    override fun onStop() {
        packageReceiver?.let { unregisterReceiver(it) }
        packageReceiver = null
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        applyBackground()
    }

    override fun onPause() {
        stopVideo()
        super.onPause()
    }

    // A launcher should stay on the home screen when Back is pressed.
    @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
    override fun onBackPressed() {
        // intentionally empty
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ---------------------------------------------------------------- keys

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (adapter.movingPkg != null) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (e.action == KeyEvent.ACTION_DOWN) {
                        val delta = if (e.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) -1 else 1
                        val to = adapter.moveMoving(delta)
                        if (to >= 0) {
                            recycler.scrollToPosition(to)
                            recycler.post {
                                recycler.findViewHolderForAdapterPosition(to)?.itemView?.requestFocus()
                            }
                        }
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> {
                    if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) finishMove()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> return true
            }
        }
        if (e.action == KeyEvent.ACTION_DOWN &&
            (e.keyCode == KeyEvent.KEYCODE_MENU || e.keyCode == KeyEvent.KEYCODE_SETTINGS)
        ) {
            showSettings()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun finishMove() {
        adapter.endMove()
        prefs.edit()
            .putString("order", adapter.apps.joinToString("\n") { it.pkg })
            .apply()
    }

    // ---------------------------------------------------------------- apps

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val found = LinkedHashMap<String, AppEntry>()
            fun collect(category: String) {
                val query = Intent(Intent.ACTION_MAIN).addCategory(category)
                for (ri in pm.queryIntentActivities(query, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || found.containsKey(pkg)) continue
                    val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                        ?: pm.getLaunchIntentForPackage(pkg)
                        ?: continue
                    found[pkg] = AppEntry(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), launch)
                }
            }
            collect(Intent.CATEGORY_LEANBACK_LAUNCHER)
            collect(Intent.CATEGORY_LAUNCHER)

            val saved = (prefs.getString("order", "") ?: "").split("\n").filter { it.isNotBlank() }
            val ordered = ArrayList<AppEntry>()
            for (pkg in saved) found.remove(pkg)?.let { ordered.add(it) }
            ordered.addAll(found.values.sortedBy { it.label.lowercase() })

            runOnUiThread {
                adapter.submit(ordered)
                recycler.post {
                    if (recycler.focusedChild == null) {
                        recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                    }
                }
            }
        }.start()
    }

    private fun launchApp(app: AppEntry) {
        try {
            startActivity(Intent(app.intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ----------------------------------------------------- character / eyes

    private fun applyCharacter() {
        val pack = store.findPack(prefs.getString("character", null))
        currentPack = pack
        characterView.setPack(store.loadBitmap(pack), pack.eyes, pack.socketColor)

        val styles = store.listEyeStyles(pack)
        val wanted = prefs.getString("eyeStyle", null)
        val style = styles.firstOrNull { it.id == wanted } ?: styles.first()
        currentStyle = style
        characterView.setEyeStyle(style)

        applyBackground()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Character: ${currentPack?.name ?: "-"}",
            "Eye style: ${currentStyle?.label ?: "-"}",
            "Background: ${backgroundLabel(prefs.getString("bg", "auto"))}",
            "Reset app order",
            "How to add characters and eye styles"
        )
        AlertDialog.Builder(this)
            .setTitle("Customize")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pickCharacter()
                    1 -> pickEyeStyle()
                    2 -> pickBackground()
                    3 -> {
                        prefs.edit().remove("order").apply()
                        loadApps()
                    }
                    4 -> showHelp()
                }
            }
            .show()
    }

    private fun pickCharacter() {
        val packs = store.listPacks()
        AlertDialog.Builder(this)
            .setTitle("Character")
            .setItems(packs.map { it.name }.toTypedArray()) { _, i ->
                prefs.edit().putString("character", packs[i].id).apply()
                applyCharacter()
            }
            .show()
    }

    private fun pickEyeStyle() {
        val pack = currentPack ?: return
        val styles = store.listEyeStyles(pack)
        AlertDialog.Builder(this)
            .setTitle("Eye style")
            .setItems(styles.map { it.label }.toTypedArray()) { _, i ->
                prefs.edit().putString("eyeStyle", styles[i].id).apply()
                currentStyle = styles[i]
                characterView.setEyeStyle(styles[i])
            }
            .show()
    }

    private fun pickBackground() {
        val modes = listOf("auto", "rain", "dark")
        AlertDialog.Builder(this)
            .setTitle("Background")
            .setItems(modes.map { backgroundLabel(it) }.toTypedArray()) { _, i ->
                prefs.edit().putString("bg", modes[i]).apply()
                applyBackground()
            }
            .show()
    }

    private fun backgroundLabel(mode: String?) = when (mode) {
        "rain" -> "Rain animation"
        "dark" -> "Plain dark"
        else -> "Auto (pack video, else rain)"
    }

    private fun showHelp() {
        AlertDialog.Builder(this)
            .setTitle("Add characters and eye styles")
            .setMessage(
                "Characters folder:\n${store.charactersDir.absolutePath}\n\n" +
                    "Eye images folder:\n${store.eyesDir.absolutePath}\n\n" +
                    "Copy your own files there (see README.md for the pack.json format), " +
                    "then open Customize again to pick them."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    // ----------------------------------------------------------- background

    private fun applyBackground() {
        stopVideo()
        val mode = prefs.getString("bg", "auto")
        val video = currentPack?.backgroundFile
        when {
            mode == "dark" -> rainView.visibility = View.GONE
            mode == "auto" && video != null -> {
                rainView.visibility = View.GONE
                startVideo(video)
            }
            else -> rainView.visibility = View.VISIBLE
        }
    }

    private fun startVideo(file: File) {
        videoView.visibility = View.VISIBLE

        fun begin(st: SurfaceTexture) {
            try {
                val s = Surface(st)
                surface = s
                val mp = MediaPlayer()
                mp.setDataSource(file.absolutePath)
                mp.setSurface(s)
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                mp.setOnPreparedListener { it.start() }
                mp.setOnErrorListener { _, _, _ -> true }
                mp.prepareAsync()
                player = mp
            } catch (e: Exception) {
                rainView.visibility = View.VISIBLE
            }
        }

        val st = videoView.surfaceTexture
        if (videoView.isAvailable && st != null) {
            begin(st)
        } else {
            videoView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) = begin(s)
                override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
            }
        }
    }

    private fun stopVideo() {
        videoView.surfaceTextureListener = null
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        player?.release()
        player = null
        surface?.release()
        surface = null
        videoView.visibility = View.GONE
    }
}
