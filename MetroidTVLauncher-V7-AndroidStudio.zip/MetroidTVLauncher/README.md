# METROID TV Launcher V6

V6 adds an on-screen settings panel and automatic biome rotation.

## Settings menu
Press MENU on the TV remote to open Suit & Arm Cannon Configuration. Use Up/Down to choose a setting, Left/Right to change it, and BACK or MENU to close.
- Ammunition Type: Power Beam, Wave Beam, Ice Beam, Plasma Beam, Missile, Super Missile, Seeker Missile.
- Samus Suit: 13 suit presets.
- Auto Biome on Start: ON by default; chooses a different biome at each launcher start and applies that biome's suggested suit. Turn it OFF to keep the current biome.
- Biome Preview: manually select one of the 12 included biome palettes.

The live wallpaper reads the saved biome preference and animates that biome's procedural environment. To set it as the system wallpaper, open Android's live wallpaper picker from the device wallpaper settings.

## Build APK
Open this project in Android Studio and run `app > assembleDebug`, or push it to GitHub and run the included Actions workflow. The APK artifact is `app/build/outputs/apk/debug/app-debug.apk`.

## Scope
This is source code, not a compiled or device-tested APK. The app is a 2D Canvas launcher with procedural cannon shapes and effects; it does not contain a rigged 3D Samus model. The live wallpaper uses procedural animated backgrounds at the device surface resolution, not extracted game maps. No copyrighted game models, textures, maps, music, or sounds are bundled. Google TV firmware may restrict third-party HOME launcher selection.


## V7 startup suit rotation
- Added a 14th selectable preset, **Custom Blue / Red Armor**, based on the user-provided visual reference image bundled as `custom_suit_reference.jpg`. This is a reference asset, not a rigged 3D model.
- Added **Auto Suit on Start** to the settings menu (ON by default). Each launcher start selects a different suit preset where possible. Turn it OFF to keep the selected suit.
- Automatic biome rotation remains independently configurable.
