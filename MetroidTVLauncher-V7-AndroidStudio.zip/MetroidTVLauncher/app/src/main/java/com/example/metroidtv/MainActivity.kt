package com.example.metroidtv

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.*
import android.os.Bundle
import android.service.wallpaper.WallpaperService
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var screen: LauncherView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        val prefs = getSharedPreferences("dock", MODE_PRIVATE)
        // Rotate the biome and suit independently on each launcher start when enabled.
        val startupEdit = prefs.edit()
        if (prefs.getBoolean("auto_biome", true)) {
            val previous = prefs.getInt("theme", -1)
            var next = (0 until 12).random()
            if (previous in 0..11 && next == previous) next = (next + 1) % 12
            startupEdit.putInt("theme", next)
        }
        if (prefs.getBoolean("auto_suit", true)) {
            val previousSuit = prefs.getInt("suit", -1)
            var nextSuit = (0 until 14).random()
            if (previousSuit in 0..13 && nextSuit == previousSuit) nextSuit = (nextSuit + 1) % 14
            startupEdit.putInt("suit", nextSuit)
        }
        startupEdit.apply()
        screen = LauncherView(this)
        setContentView(screen)
    }
    override fun onResume() { super.onResume(); if (::screen.isInitialized) screen.refreshApps() }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = if (::screen.isInitialized && screen.handleKey(keyCode)) true else super.onKeyDown(keyCode, event)

    inner class LauncherView(activity: Activity) : View(activity) {
        data class AppEntry(val label: String, val pkg: String, val icon: android.graphics.drawable.Drawable)
        private val prefs = getSharedPreferences("dock", MODE_PRIVATE)
        private val apps = mutableListOf<AppEntry>()
        private var selected = 0
        private var moveMode = false
        private var settingsOpen = false
        private var settingsRow = 0
        private var autoBiome = prefs.getBoolean("auto_biome", true)
        private var autoSuit = prefs.getBoolean("auto_suit", true)
        private var theme = prefs.getInt("theme", 0).coerceIn(0, 11)
        private var suit = prefs.getInt("suit", 0).coerceIn(0, 13)
        private var ammo = prefs.getInt("ammo", 0).coerceIn(0, 6)
        private val ammoNames = arrayOf("POWER BEAM", "WAVE BEAM", "ICE BEAM", "PLASMA BEAM", "MISSILE", "SUPER MISSILE", "SEEKER MISSILE")
        private val ammoColors = intArrayOf(Color.rgb(100,220,255), Color.rgb(170,110,255), Color.rgb(130,220,255), Color.rgb(255,120,55), Color.rgb(255,190,70), Color.rgb(255,90,60), Color.rgb(100,255,180))
        private var firingUntil = 0L
        private var frame = 0
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }
        private val cover by lazy { BitmapFactory.decodeResource(resources, R.drawable.samus_reference) }
        private val themeNames = arrayOf(
            "TALLON OVERWORLD · PRIME", "PHENDRANA DRIFTS · PRIME", "MAGMOOR CAVERNS · PRIME", "PHAZON MINES · PRIME",
            "CHOZO RUINS · PRIME", "TORVUS BOG · ECHOES", "AGÓN WASTELANDS · ECHOES", "SANCTUARY FORTRESS · ECHOES",
            "SKYTOWN · CORRUPTION", "BRYNNA · PRIME 3", "ARTARIA · DREAD", "PLANET ZDR · DREAD"
        )
        private val suitNames = arrayOf(
            "POWER SUIT", "VARIA SUIT", "GRAVITY SUIT", "PHAZON SUIT", "LIGHT SUIT", "DARK SUIT",
            "PED SUIT", "FUSION SUIT", "ZERO SUIT", "SAMUS RETURNS VARIA", "DREAD POWER SUIT",
            "DREAD VARIA SUIT", "METROID SUIT", "CUSTOM BLUE / RED ARMOR"
        )
        // Suggested loadout for each biome; users can override it with Channel +/-.
        private val biomeSuitDefaults = intArrayOf(1, 2, 1, 3, 0, 2, 5, 4, 6, 6, 11, 12)
        private val palettes = arrayOf(
            intArrayOf(Color.rgb(5, 12, 34), Color.rgb(10, 75, 105), Color.rgb(255, 142, 35)),
            intArrayOf(Color.rgb(8, 24, 43), Color.rgb(45, 105, 145), Color.rgb(155, 226, 255)),
            intArrayOf(Color.rgb(30, 8, 8), Color.rgb(125, 42, 20), Color.rgb(255, 95, 30)),
            intArrayOf(Color.rgb(15, 5, 35), Color.rgb(83, 30, 125), Color.rgb(75, 238, 255)),
            intArrayOf(Color.rgb(18, 25, 20), Color.rgb(67, 105, 64), Color.rgb(197, 180, 89)),
            intArrayOf(Color.rgb(7, 28, 28), Color.rgb(19, 100, 94), Color.rgb(79, 225, 195)),
            intArrayOf(Color.rgb(29, 22, 9), Color.rgb(112, 83, 31), Color.rgb(255, 193, 74)),
            intArrayOf(Color.rgb(9, 17, 30), Color.rgb(44, 78, 112), Color.rgb(143, 190, 255)),
            intArrayOf(Color.rgb(10, 24, 39), Color.rgb(41, 90, 125), Color.rgb(91, 202, 255)),
            intArrayOf(Color.rgb(16, 18, 34), Color.rgb(62, 73, 116), Color.rgb(191, 156, 255)),
            intArrayOf(Color.rgb(22, 8, 27), Color.rgb(99, 30, 91), Color.rgb(255, 94, 188)),
            intArrayOf(Color.rgb(8, 18, 27), Color.rgb(28, 77, 92), Color.rgb(85, 231, 222))
        )
        init { isFocusable = true; isFocusableInTouchMode = true; requestFocus(); loadApps() }
        fun refreshApps() { loadApps(); invalidate() }
        private fun loadApps() {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val found: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
            val all = found.map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .filter { it.pkg != packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
            val order = prefs.getString("order", "").orEmpty().split('|').filter { it.isNotBlank() }
            apps.clear(); apps.addAll(order.mapNotNull { p -> all.find { it.pkg == p } })
            apps.addAll(all.filter { a -> apps.none { it.pkg == a.pkg } })
            selected = if (apps.isEmpty()) 0 else selected.coerceIn(0, apps.lastIndex)
        }
        private fun saveOrder() { prefs.edit().putString("order", apps.joinToString("|") { it.pkg }).apply() }
        private fun changeTheme() {
            theme = (theme + 1) % palettes.size
            suit = biomeSuitDefaults[theme]
            prefs.edit().putInt("theme", theme).putInt("suit", suit).apply()
            invalidate()
        }
        private fun changeSuit(delta: Int) { suit = (suit + delta + suitNames.size) % suitNames.size; prefs.edit().putInt("suit", suit).apply(); invalidate() }
        private fun changeAmmo(delta: Int) { ammo = (ammo + delta + ammoNames.size) % ammoNames.size; prefs.edit().putInt("ammo", ammo).apply(); invalidate() }
        private fun openWallpaperPicker() {
            try {
                val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@MainActivity, MetroidLiveWallpaper::class.java)
                )
                startActivity(intent)
            } catch (_: Exception) { try { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) } catch (_: Exception) { } }
        }
        fun handleKey(code: Int): Boolean {
            if (settingsOpen) {
                when (code) {
                    KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_MENU -> { settingsOpen = false; invalidate(); return true }
                    KeyEvent.KEYCODE_DPAD_UP -> { settingsRow = (settingsRow - 1).coerceAtLeast(0); invalidate(); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { settingsRow = (settingsRow + 1).coerceAtMost(4); invalidate(); return true }
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        val delta = if (code == KeyEvent.KEYCODE_DPAD_LEFT) -1 else 1
                        when (settingsRow) {
                            0 -> changeAmmo(delta)
                            1 -> changeSuit(delta)
                            2 -> { autoBiome = !autoBiome; prefs.edit().putBoolean("auto_biome", autoBiome).apply() }
                            3 -> changeTheme()
                            4 -> { autoSuit = !autoSuit; prefs.edit().putBoolean("auto_suit", autoSuit).apply() }
                        }
                        invalidate(); return true
                    }
                }
                return true
            }
            if (apps.isEmpty()) return when(code) { KeyEvent.KEYCODE_MENU -> { settingsOpen = true; invalidate(); true }; KeyEvent.KEYCODE_SETTINGS -> { openWallpaperPicker(); true }; else -> false }
            when (code) {
                KeyEvent.KEYCODE_DPAD_UP -> { changeAmmo(-1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN -> { changeAmmo(1); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { if (moveMode) swap(-1) else selected = (selected - 1).coerceAtLeast(0); invalidate(); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { if (moveMode) swap(1) else selected = (selected + 1).coerceAtMost(apps.lastIndex); invalidate(); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (moveMode) { moveMode = false; saveOrder() }
                    else { firingUntil = System.currentTimeMillis() + 620; invalidate(); postDelayed({ launchSelected() }, 260) }
                    invalidate(); return true
                }
                KeyEvent.KEYCODE_MENU -> { settingsOpen = true; settingsRow = 0; invalidate(); return true }
                KeyEvent.KEYCODE_SETTINGS -> { openWallpaperPicker(); return true }
                KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { changeSuit(-1); return true }
                KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { changeSuit(1); return true }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_BUTTON_START -> { moveMode = !moveMode; invalidate(); return true }
                KeyEvent.KEYCODE_BACK -> { if (moveMode) { moveMode = false; invalidate(); return true } }
            }
            return false
        }
        private fun swap(delta: Int) { val n = selected + delta; if (n in apps.indices) { val a = apps[selected]; apps[selected] = apps[n]; apps[n] = a; selected = n; invalidate() } }
        private fun launchSelected() {
            val app = apps.getOrNull(selected) ?: return
            try { packageManager.getLaunchIntentForPackage(app.pkg)?.let { startActivity(it) } } catch (_: Exception) { }
        }
        // Procedural 2D arm-cannon rig: rotates toward the selected dock tile,
        // pulses while charging, and recoils during the launch shot.
        private fun drawCannonRig(c: Canvas, muzzleX: Float, muzzleY: Float, targetX: Float, targetY: Float, accent: Int, firing: Boolean) {
            val dx = targetX - muzzleX
            val dy = targetY - muzzleY
            val angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
            val recoil = if (firing) 12f + (frame % 4) * 2f else 0f
            val save = c.save()
            c.rotate(angle, muzzleX, muzzleY)
            val metal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF263B4B.toInt(); style = Paint.Style.FILL }
            val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9CB7C9.toInt(); style = Paint.Style.STROKE; strokeWidth = max(2f, width/700f) }
            val ammoColor = ammoColors[ammo]
            val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ammoColor; style = Paint.Style.FILL; setShadowLayer(max(5f,width/150f),0f,0f,max(5f,width/150f),ammoColor) }
            // The muzzle assembly changes silhouette with the selected beam/missile mode.
            c.drawRoundRect(muzzleX-104f-recoil, muzzleY-25f, muzzleX-8f-recoil, muzzleY+25f, 15f,15f,metal)
            c.drawRoundRect(muzzleX-88f-recoil, muzzleY-29f, muzzleX-18f-recoil, muzzleY+29f, 12f,12f,edge)
            when (ammo) {
                0 -> c.drawRoundRect(muzzleX-15f-recoil,muzzleY-18f,muzzleX+15f-recoil,muzzleY+18f,8f,8f,metal)
                1 -> { c.drawCircle(muzzleX-recoil,muzzleY,24f,edge); c.drawCircle(muzzleX-recoil,muzzleY,15f,glow) }
                2 -> { c.drawRoundRect(muzzleX-20f-recoil,muzzleY-25f,muzzleX+13f-recoil,muzzleY+25f,5f,5f,edge); c.drawCircle(muzzleX-recoil,muzzleY,13f,glow) }
                3 -> { val path=Path().apply { moveTo(muzzleX-18f-recoil,muzzleY-26f); lineTo(muzzleX+20f-recoil,muzzleY); lineTo(muzzleX-18f-recoil,muzzleY+26f); close() }; c.drawPath(path,glow) }
                else -> { c.drawRoundRect(muzzleX-25f-recoil,muzzleY-22f,muzzleX+19f-recoil,muzzleY+22f,7f,7f,edge); c.drawCircle(muzzleX-recoil,muzzleY,if(ammo==6)20f else 16f,glow) }
            }
            c.drawCircle(muzzleX-recoil, muzzleY, if(firing) 15f else 9f, glow)
            c.drawCircle(muzzleX-recoil, muzzleY, if(firing) 7f else 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE })
            c.restoreToCount(save)
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c); frame++
            val w = width.toFloat(); val h = height.toFloat(); val p = palettes[theme]
            c.drawColor(p[0])
            bg.shader = RadialGradient(w*.5f, h*.38f, h*.75f, intArrayOf(p[1], p[0]), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, bg); bg.shader = null
            for (i in 0 until 150) {
                val x = ((i * 7919L % 10007L) / 10007f) * w
                val y = (((i * 3571L % 9973L) / 9973f) * h + frame * (if(i%4==0) .12f else .035f)) % h
                bg.color = Color.argb(100 + ((i * 17 + frame / 5) % 150), 210, 235, 255)
                c.drawCircle(x, y, if (i % 9 == 0) max(2f,w/900f) else max(1f,w/1800f), bg)
            }
            // Original user-supplied Samus Returns artwork, scaled to the TV canvas.
            val artW = min(w*.49f, h*.88f); val artH = artW
            val dst = RectF(w*.255f, h*.015f, w*.255f+artW, h*.015f+artH)
            bg.alpha = 238; c.drawBitmap(cover, null, dst, bg); bg.alpha = 255
            text.textAlign = Paint.Align.LEFT; text.color = Color.WHITE; text.textSize = h*.043f
            c.drawText("GALACTIC COMMAND  //  HOME", w*.045f, h*.075f, text)
            text.textSize = h*.020f; text.color = Color.argb(205, 210, 235, 255)
            c.drawText("◀ ▶ APPS   ▲ ▼ AMMO   OK FIRE / LAUNCH   PLAY-PAUSE REORDER   MENU BIOME   CH +/- SUIT", w*.045f, h*.12f, text)
            text.textSize = h*.022f; text.color = p[2]
            c.drawText("SUIT  //  ${suitNames[suit]}", w*.045f, h*.165f, text)
            text.textSize=h*.018f; text.color=ammoColors[ammo]
            c.drawText("ARM CANNON  //  ${ammoNames[ammo]}", w*.045f, h*.205f, text)
            val dockTop = h*.70f
            bg.shader = LinearGradient(0f, dockTop, 0f, h, 0xEE06101F.toInt(), 0xF900050D.toInt(), Shader.TileMode.CLAMP)
            c.drawRoundRect(w*.025f, dockTop, w*.975f, h*.97f, 24f, 24f, bg); bg.shader = null
            text.textSize = h*.026f; text.color = p[2]
            c.drawText(if(moveMode) "DOCK CONFIG  //  MOVE WITH LEFT / RIGHT, OK TO SAVE" else "TACTICAL HUD  //  ${themeNames[theme]}  //  HOLD PLAY-PAUSE TO REARRANGE", w*.05f, dockTop+h*.075f, text)
            if (apps.isEmpty()) { text.color=Color.WHITE; text.textSize=30f; c.drawText("No launchable apps found",w*.1f,dockTop+h*.35f,text); return }
            val count = min(apps.size, 9); val cellW = w*.90f/count; val startX = w*.05f
            // Keep selected tile in the visible nine-item window while traversing long app lists.
            val first = (selected - count/2).coerceIn(0, max(0, apps.size-count))
            for (slot in 0 until count) {
                val index = first + slot; val app = apps[index]
                val cx = startX + cellW*(slot+.5f); val cy = dockTop+h*.245f
                val active = index == selected
                bg.color = if (active) Color.argb(235, 16, 55, 78) else Color.argb(150, 12, 22, 36)
                c.drawRoundRect(cx-cellW*.44f, dockTop+h*.12f, cx+cellW*.44f, h*.94f, 18f,18f,bg)
                if (active) { bg.style=Paint.Style.STROKE; bg.strokeWidth=max(3f,w/500f); bg.color=p[2]; c.drawRoundRect(cx-cellW*.44f,dockTop+h*.12f,cx+cellW*.44f,h*.94f,18f,18f,bg); bg.style=Paint.Style.FILL }
                val size = min(cellW*.42f,h*.105f).toInt().coerceAtLeast(36)
                val left=(cx-size/2).toInt(); val top=(cy-size/2).toInt()
                app.icon.setBounds(left,top,left+size,top+size); app.icon.draw(c)
                text.textSize=h*.021f; text.color=if(active) Color.WHITE else 0xFFB9C9D8.toInt(); text.textAlign=Paint.Align.CENTER
                val label=if(app.label.length>15) app.label.take(14)+"…" else app.label
                c.drawText(label,cx,dockTop+h*.34f,text)
                if (active) { text.textSize=h*.016f; text.color=p[2]; c.drawText(if(moveMode) "MOVING" else "TARGET LOCK",cx,dockTop+h*.39f,text) }
            }
            val slot = selected-first
            val targetX = startX + cellW*(slot+.5f)
            val targetY = dockTop+h*.16f
            // Aim point is aligned to the cannon muzzle in the supplied cover artwork.
            val originX=w*.49f; val originY=h*.57f
            val firing = System.currentTimeMillis()<firingUntil
            drawCannonRig(c, originX, originY, targetX, targetY, p[2], firing)
            val shotColor = ammoColors[ammo]
            bg.color=shotColor; bg.strokeWidth=if(firing) max(8f,w/210f) else max(2f,w/650f); bg.style=Paint.Style.STROKE
            bg.pathEffect=DashPathEffect(floatArrayOf(max(8f,w/160f),max(6f,w/220f)),0f)
            c.drawLine(originX,originY,targetX,targetY,bg); bg.pathEffect=null; bg.style=Paint.Style.FILL
            if(firing) {
                val pulse = 1f + (frame%8)*.12f
                bg.color=Color.WHITE; c.drawCircle(targetX,targetY,18f*pulse,bg)
                bg.color=shotColor; c.drawCircle(targetX,targetY,34f*pulse,bg)
                bg.color=Color.argb(90,255,255,255); c.drawCircle(targetX,targetY,52f*pulse,bg)
            }
            if (settingsOpen) drawSettings(c, w, h, p)
            if (frame % 2 == 0) postInvalidateDelayed(40)
        }

        private fun drawSettings(c: Canvas, w: Float, h: Float, p: IntArray) {
            val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC020814.toInt() }
            c.drawRect(0f, 0f, w, h, shade)
            val panel = RectF(w*.22f, h*.13f, w*.78f, h*.88f)
            shade.color = 0xF20A1B2B.toInt(); c.drawRoundRect(panel, 28f, 28f, shade)
            shade.color = p[2]; shade.style = Paint.Style.STROKE; shade.strokeWidth = max(3f,w/600f)
            c.drawRoundRect(panel, 28f, 28f, shade); shade.style = Paint.Style.FILL
            text.textAlign = Paint.Align.LEFT; text.color = Color.WHITE; text.textSize = h*.045f
            c.drawText("SUIT & ARM CANNON CONFIGURATION", w*.26f, h*.22f, text)
            val labels = arrayOf("AMMUNITION TYPE", "SAMUS SUIT", "AUTO BIOME ON START", "BIOME PREVIEW", "AUTO SUIT ON START")
            val values = arrayOf(ammoNames[ammo], suitNames[suit], if(autoBiome) "ON · RANDOM EACH START" else "OFF · KEEP CURRENT", themeNames[theme], if(autoSuit) "ON · RANDOM EACH START" else "OFF · KEEP CURRENT")
            for (i in labels.indices) {
                val y = h*(.29f + i*.105f)
                if (i == settingsRow) { shade.color = 0xFF173D55.toInt(); c.drawRoundRect(w*.25f,y-h*.065f,w*.75f,y+h*.035f,14f,14f,shade); shade.color=p[2]; shade.style=Paint.Style.STROKE; c.drawRoundRect(w*.25f,y-h*.065f,w*.75f,y+h*.035f,14f,14f,shade); shade.style=Paint.Style.FILL }
                text.textSize = h*.022f; text.color = 0xFF9FC5D8.toInt(); c.drawText(labels[i],w*.28f,y-h*.012f,text)
                text.textSize = h*.027f; text.color = if(i==settingsRow) Color.WHITE else p[2]; c.drawText(values[i],w*.49f,y-h*.012f,text)
            }
            text.textSize = h*.018f; text.color = 0xFFB8C9D8.toInt()
            c.drawText("UP / DOWN: ROW     LEFT / RIGHT: CHANGE     BACK: CLOSE",w*.28f,h*.84f,text)
        }
    }
}
