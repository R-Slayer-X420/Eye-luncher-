package com.example.metroidtv

import android.graphics.*
import android.os.Handler
import android.os.HandlerThread
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.*
import kotlin.random.Random

/** Procedural 4K-friendly animated wallpaper. It renders at the device's native surface size. */
class MetroidLiveWallpaper : WallpaperService() {
    override fun onCreateEngine(): Engine = SceneEngine()

    inner class SceneEngine : Engine() {
        private val thread = HandlerThread("MetroidWallpaper").apply { start() }
        private val handler = Handler(thread.looper)
        private var visible = false
        private var frame = 0L
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stars = List(150) { i -> Star(((i * 7919) % 10007) / 10007f, ((i * 3571) % 9973) / 9973f, 0.5f + (i % 5) * .35f, i % 11 == 0) }
        private data class Star(val x: Float, val y: Float, val radius: Float, val bright: Boolean)
        private val drawFrame = object : Runnable { override fun run() { if (visible) { draw(); handler.postDelayed(this, 33) } } }

        override fun onVisibilityChanged(isVisible: Boolean) { visible = isVisible; handler.removeCallbacks(drawFrame); if (visible) handler.post(drawFrame) }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { super.onSurfaceChanged(holder, format, width, height); if (visible) { handler.removeCallbacks(drawFrame); handler.post(drawFrame) } }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) { visible = false; handler.removeCallbacks(drawFrame); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { visible = false; handler.removeCallbacksAndMessages(null); thread.quitSafely(); super.onDestroy() }

        private fun draw() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas() ?: return
                val w = c.width.toFloat(); val h = c.height.toFloat(); val theme = getSharedPreferences("dock", MODE_PRIVATE).getInt("theme", 0).coerceIn(0, 11)
                val palettes = arrayOf(
                    intArrayOf(Color.rgb(3, 8, 28), Color.rgb(10, 55, 94), Color.rgb(255, 143, 42)),
                    intArrayOf(Color.rgb(5, 19, 30), Color.rgb(21, 92, 115), Color.rgb(155, 226, 255)),
                    intArrayOf(Color.rgb(28, 5, 12), Color.rgb(125, 28, 18), Color.rgb(255, 100, 30)),
                    intArrayOf(Color.rgb(13, 4, 30), Color.rgb(62, 22, 105), Color.rgb(66, 238, 255)),
                    intArrayOf(Color.rgb(18, 25, 20), Color.rgb(67, 105, 64), Color.rgb(197, 180, 89)),
                    intArrayOf(Color.rgb(7, 28, 28), Color.rgb(19, 100, 94), Color.rgb(79, 225, 195)),
                    intArrayOf(Color.rgb(29, 22, 9), Color.rgb(112, 83, 31), Color.rgb(255, 193, 74)),
                    intArrayOf(Color.rgb(9, 17, 30), Color.rgb(44, 78, 112), Color.rgb(143, 190, 255)),
                    intArrayOf(Color.rgb(10, 24, 39), Color.rgb(41, 90, 125), Color.rgb(91, 202, 255)),
                    intArrayOf(Color.rgb(16, 18, 34), Color.rgb(62, 73, 116), Color.rgb(191, 156, 255)),
                    intArrayOf(Color.rgb(22, 8, 27), Color.rgb(99, 30, 91), Color.rgb(255, 94, 188)),
                    intArrayOf(Color.rgb(8, 18, 27), Color.rgb(28, 77, 92), Color.rgb(85, 231, 222))
                )
                val p = palettes[theme.coerceIn(0, palettes.lastIndex)]
                c.drawColor(p[0])
                paint.shader = RadialGradient(w*.52f, h*.43f, h*.9f, intArrayOf(p[1], p[0]), null, Shader.TileMode.CLAMP)
                c.drawRect(0f,0f,w,h,paint); paint.shader = null
                stars.forEachIndexed { i, s ->
                    val drift = (frame * (if (i % 3 == 0) .00012f else .000035f)) % 1f
                    val y = ((s.y + drift) % 1f) * h
                    paint.color = Color.argb(if (s.bright) (150 + (frame/8%100).toInt()) else 115, 220, 235, 255)
                    c.drawCircle(s.x*w, y, s.radius * max(1f,w/1920f), paint)
                }
                // Planet / biome horizon and layered silhouettes.
                val horizon = h*.67f
                paint.shader = LinearGradient(0f,horizon,0f,h,intArrayOf(p[1],p[0]),Shader.TileMode.CLAMP)
                c.drawRect(0f,horizon,w,h,paint); paint.shader = null
                paint.color = p[2]; paint.alpha = 110
                paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f,w/1000f)
                c.drawArc(w*.08f,h*.49f,w*.92f,h*1.17f,190f,160f,false,paint); paint.style=Paint.Style.FILL; paint.alpha=255
                val path = Path().apply { moveTo(0f,h*.78f); lineTo(w*.12f,h*.69f); lineTo(w*.22f,h*.75f); lineTo(w*.37f,h*.65f); lineTo(w*.52f,h*.76f); lineTo(w*.68f,h*.67f); lineTo(w*.82f,h*.74f); lineTo(w,h*.64f); lineTo(w,h); lineTo(0f,h); close() }
                paint.color = when(theme) {
                    1, 8 -> 0xFF153D50.toInt(); 2 -> 0xFF45170F.toInt(); 3, 9 -> 0xFF21133C.toInt()
                    5 -> 0xFF173E3A.toInt(); 6 -> 0xFF4B3A1B.toInt(); 7 -> 0xFF25324A.toInt()
                    10, 11 -> 0xFF102D32.toInt(); else -> 0xFF102D32.toInt()
                }
                c.drawPath(path,paint)
                // Atmospheric particles and subtle energy motes.
                for (i in 0 until 24) { val x=((i*421 + frame*(i%3+1))%(w.toInt().coerceAtLeast(1))).toFloat(); val y=horizon+(i*97%max(1,(h-horizon).toInt())); paint.color=p[2]; paint.alpha=70; c.drawCircle(x,y,2f*max(1f,w/1920f),paint) }
                paint.alpha=255
                frame++
            } catch (_: Exception) { } finally { if (c != null) try { holder.unlockCanvasAndPost(c) } catch (_: Exception) { } }
        }
    }
}
