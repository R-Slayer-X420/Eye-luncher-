plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.metroidtv"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.metroidtv"
        minSdk = 23
        targetSdk = 28
        versionCode = 7
        versionName = "3.0"
    }
}
